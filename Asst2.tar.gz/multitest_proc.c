#include "multitest.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <math.h>
#include <signal.h>
#include <stdlib.h>

int search(int* ptr, int size, int findval, int subsize)
{
	// Getting the pid of the parent process
	pid_t pid;
	pid = getpid();
	int numProc, numGroups, lastIndex;
	// Calculates the last index of the array to search.
	lastIndex = (((subsize) * (size / subsize)) + (size % subsize));
	// This if/else calculates the number of process groups needed to search the list.
	// if (size % subsize) != 0 that means there will need to be another process to search the last incomplete chunk.
	if(size % subsize != 0)
	{
		numGroups = (size / subsize) + 1;
	}
	else
	{
		// size % subsize divides evenly.
		numGroups = size / subsize;
	}
	// arr variable will be used to keep track of all process id's that are created below.
	int arr[numGroups];
	int loop;
	// initializing arr to 0
	for(loop = 0; loop < numGroups; loop++)
	{
		arr[loop] = 0;
	}
	// the first entry in arr will contain the process id of the first parent.
	arr[0] = (int)pid;
	
	// the for loop below is where the forking is happening. This method works by having the parent enter the for loop and
	// create a child process. The parent immediately leaves the for loop while the child process continues in
	// the if statement where the process id of the child is entered into arr. That original child process 
	// executes the next iteration of the for loop where it creates its own child and immediately leaves the
	// for loop. This process repeats for however many processes are needed.
	pid_t newid;
	pid_t id;
	int i, x;
	// the parent process will be searching the first chunk of the list so we only need create (numGroups - 1) processes.
	for(i = 0; i < (numGroups - 1); i++)
	{
		id = fork();
		// if parent exit for loop, if child execute what is inside if statement.
		if(id == 0)
		{
			pid_t newid = getpid();
			if(newid != pid)
			{
				for(x = 0; x < numGroups; x++)
				{
					// Iterate through arr until an empty spot is found, then insert process id. 
					if(arr[x] == 0)
					{
						arr[x] = (int)newid;
						x = numGroups;
					}
					else if(x == numGroups - 1)
					{
						// if too many processes are created, kill extras.
						kill(newid, SIGTERM);
					}
				}
			}
		}
		else
		{
			i = numGroups;
		}
	}
	// this for loop below calculates the indices for each process to search in the list. It does this by looping through
	// arr and when it finds its own process id, it multiplies the position of its pid in arr by the subsize. This is
	// used as the startIndex. The endIndex is calculated by adding the startIndex with the subsize. If that
	// result goes out of bounds of the last index, then endIndex is set equal to the variable lastIndex.
	int startIndex, endIndex;
	newid = getpid();
	for(i = 0; i < numGroups; i++)
	{	
		if(arr[i] == (int)newid)
		{
			startIndex = subsize * i;
			endIndex = startIndex + subsize;
			if(endIndex > lastIndex)
			{
				endIndex = lastIndex;
			}
		}
	}
	// each process searches its own chunk of the list looking for the value.
	for(i = startIndex; i < endIndex; i++)
	{
		if(ptr[i] == findval)
		{
			if(getpid() == pid)
			{
				// if the first parent process finds the value
				if((numGroups - 1) == 0)
				{
					// if the parent process is the only group searching the list, return 1 indicating
					// that the value was found.
					return 1;
				}
				else
				{
					// if there is more than just 1 process searching the list, wait() and then return 1.
					wait();
					return 1;
				}
			}
			else
			{
				// if a process other than the first parent finds the value, wait() and exit with exit status '130'
				// to indicate to its parent that the value has been found.
				wait();
				exit(130);
			}
		}
	}
	
	int exitstatus;
	// if the current process is not the last process that was created, wait for child process to terminate and retrieve exit status.
	if((int)getpid() != arr[numGroups - 1])
	{
		waitpid(-1, &exitstatus, 0);
	}
	else
	{
		// if the last process did not find the value, exit with exit status '122' to indicate to its parent that it did 
		// not find the value.
		exit(122);
	}
	pid_t id1 = getpid();
	// if process exited normally...
	if(WIFEXITED(exitstatus))
	{
		// retrieve exit status
		int newstatus = WEXITSTATUS(exitstatus);
		if(id1 == pid)
		{
			// if current process is the first parent, check if status is 130 or 122 and return 1 if it is 130
			// and return -1 if it is 122 to indicate that the value was not found.
			if(newstatus == 130)
			{
				return 1;
			}
			else if(newstatus == 122)
			{
				return -1;
			}
		}
		// if the current process is not the first parent, exit with the status retrieved from the child.
		else if(newstatus == 130)
		{
			exit(newstatus);
		}
		else
		{
			exit(122);
		}
	}
}
