#include "multitest.h"
#include <sys/time.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <math.h>
#include <signal.h>
#include <stdlib.h>

void calculateStats(long min1, long max1, long mean1, double std1, int size, int subsize, long arr1[])
{
	// This function takes an array as a parameter which contains the times it took for the value to be found.
	// it finds the minimum, maximum, average, and standard deviation of the values in the array.
	std1 = 0;
	mean1 = 0;
	int i;
	for(i = 0; i < 100; i++)
	{
		if(i == 0)
		{
			min1 = arr1[i];
			max1 = arr1[i];
		}
		if(i != 0)
		{
			if(arr1[i] < min1)
			{
				min1 = arr1[i];
			}
			if(arr1[i] > max1)
			{
				max1 = arr1[i];
			}
		}
		mean1 = mean1 + arr1[i];
	}
	mean1 = mean1 / 100;
	
	for(i = 0; i < 100; i++)
	{
		std1 = (pow(arr1[i] - mean1, 2)) + std1;
	}
	std1 = pow((std1 / 100), .5);
	double result = ((double)size / (double)subsize);
	int temp = (int)result;
	if(floor(result) != result)
	{
		temp = temp + 1;
	}
	printf("Min time for list of %d integers with %d processes/threads was %ld microseconds.\n", size, temp, min1);
	printf("Max time for list of %d integers with %d processes/threads was %ld microseconds.\n", size, temp, max1);
	printf("Avg time for list of %d integers with %d processes/threads was %ld microseconds.\n", size, temp, mean1);
	printf("Standard deviation for list of %d integers with subsize %d was %lf.\n", size, subsize, std1);
	printf("\n");
}

void searcher(long arr[], int* ptr, int size, int findval, int subsize)
{
	// This function takes a list as a parameter along with the size of the list and the size each process/thread
	// is searching. It also takes findval as a parameter which is the value in the list to find.
	srand(time(0));
	int i;
	int val = 1;
	int location;
	// populate the list and keep track of the location of the value.
	for(i = 0; i < size; i++)
	{
		ptr[i] = val;
		if(val == findval)
		{
			location = i;
		}
		++val;
	}
	int random, random1;
	// scramble the list by generating two random indices and swapping the values at that location.
	// also keep track of where the value is with the variable location.
	for(i = 0; i < size; i++)
	{
		random = (rand() % size);
		random1 = (rand() % size);
		if((random == location) || (random1 == location))
		{
			if(random == location)
			{
				location = random1;
			}
			else
			{
				location = random;
			}
		}
		int temp = ptr[random];
		ptr[random] = ptr[random1];
		ptr[random1] = temp;
	}
	int rando;
	// search the list 100 times and insert the time it took to find the value into array named "arr".
	for(i = 0; i < 100; i++)
	{
		long timepassed;
		struct timeval time1;
		struct timeval time2;
		int index;
		gettimeofday(&time1, 0);
		index = dummy(ptr, size, findval, subsize);
		gettimeofday(&time2, 0);
		timepassed = (time2.tv_sec-time1.tv_sec)*1000000 + time2.tv_usec-time1.tv_usec;
		if(index == -1)
		{
			printf("Value is not in the list.\n");
			exit(0);
		}
		arr[i] = timepassed;
		rando = (rand() % size);
		int temp = ptr[rando];
		ptr[rando] = ptr[location];
		ptr[location] = temp;
		location = rando;
	}
}

long testA()
{
	int i;
	printf("Running Test Case A.\n");
	long timeTestA;
	struct timeval time01;
	struct timeval time02;
	gettimeofday(&time01, 0);
	
	// first list is size 500 with subsizes of 250
	int size1 = 500;
	int subsize1 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size1, subsize1);
	int findval = ((rand() % (size1 - 1)) + 1);
	int* ptr = (int*)malloc(sizeof(int) * size1);
	long arr1[100];
	// search list 100 times and keep times in value arr1.
	searcher(arr1, ptr, size1, findval, subsize1);
	//printf("\nAFTER\n");
	
	// list of size 1000 with subsizes of 250
	int size2 = 1000;
	int subsize2 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size2, subsize2);
	findval = ((rand() % (size2 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size2);
	long arr2[100];
	// search list 100 times and keep times in value arr2.
	searcher(arr2, ptr, size2, findval, subsize2);
	
	// list of size 2000 with subsizes of 250
	int size3 = 2000;
	int subsize3 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size3, subsize3);
	findval = ((rand() % (size3 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size3);
	long arr3[100];
	// search list 100 times and keep times in value arr3.
	searcher(arr3, ptr, size3, findval, subsize3);
	
	// list of size 3000 with subsizes 250
	int size10 = 3000;
	int subsize10 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size10, subsize10);
	findval = ((rand() % (size10 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size10);
	long arr10[100];
	// search list 100 times and keep times in value arr3.
	searcher(arr10, ptr, size10, findval, subsize10);
	
	// list of size 4000 with subsizes 250
	int size9 = 4000;
	int subsize9 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size9, subsize9);
	findval = ((rand() % (size9 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size9);
	long arr9[100];
	// search list 100 times and keep times in value arr9.
	searcher(arr9, ptr, size9, findval, subsize9);
	
	// list of size 5000 and subsizes of 250
	int size8 = 5000;
	int subsize8 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size8, subsize8);
	findval = ((rand() % (size8 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size8);
	long arr8[100];
	// search list 100 times and keep times in value arr8.
	searcher(arr8, ptr, size8, findval, subsize8);
	
	// list of size 6000 and subsizes 250
	int size7 = 6000;
	int subsize7 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size7, subsize7);
	findval = ((rand() % (size7 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size7);
	long arr7[100];
	// search list 100 times and keep times in value arr8.
	searcher(arr7, ptr, size7, findval, subsize7);
	
	// list of size 7000 and subsizes 250
	int size6 = 7000;
	int subsize6 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size6, subsize6);
	findval = ((rand() % (size6 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size6);
	long arr6[100];
	// search list 100 times and keep times in value arr6.
	searcher(arr6, ptr, size6, findval, subsize6);
	
	// list of size 8000 and subsizes 250
	int size4 = 8000;
	int subsize4 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size4, subsize4);
	findval = ((rand() % (size4 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size4);
	long arr4[100];
	// search list 100 times and keep times in value arr6.
	searcher(arr4, ptr, size4, findval, subsize4);
	
	// size of 9000 with subsizes 250
	int size5 = 9000;
	int subsize5 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n\n", size5, subsize5);
	findval = ((rand() % (size5 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size5);
	long arr5[100];
	// search list 100 times and keep times in value arr5
	searcher(arr5, ptr, size5, findval, subsize5);
	
	free(ptr);
	
	// calculate statistics.
	long mean1, mean2, mean3, mean4, mean5, mean6, mean7, mean8, mean9, mean10;
	long min1, min2, min3, min4, min5, min6, min7, min8, min9, min10;
	long max1, max2, max3, max4, max5, max6, max7, max8, max9, max10;
	double std1, std2, std3, std4, std5, std6, std7, std8, std9, std10;
	
	calculateStats(min1, max1, mean1, std1, size1, subsize1, arr1);
	calculateStats(min2, max2, mean2, std2, size2, subsize2, arr2);
	calculateStats(min3, max3, mean3, std3, size3, subsize3, arr3);
	calculateStats(min10, max10, mean10, std10, size10, subsize10, arr10);
	calculateStats(min9, max9, mean9, std9, size9, subsize9, arr9);
	calculateStats(min8, max8, mean8, std8, size8, subsize8, arr8);
	calculateStats(min7, max7, mean7, std7, size7, subsize7, arr7);
	calculateStats(min6, max6, mean5, std6, size6, subsize6, arr6);
	calculateStats(min4, max4, mean4, std4, size4, subsize4, arr4);
	calculateStats(min5, max5, mean5, std5, size5, subsize5, arr5);
	
	
	gettimeofday(&time02, 0);
	timeTestA = (time02.tv_sec-time01.tv_sec)*1000000 + time02.tv_usec-time01.tv_usec;
	
	return timeTestA;
}

long testB1()
{
	// This is the second part of Test Case B for testing Processing.
	// This test case and every one after is the same exact format as Test Case A but with different sizes and subsizes.
	int i;
	printf("Running Test Case B1.\n");
	long timeTestA;
	struct timeval time01;
	struct timeval time02;
	gettimeofday(&time01, 0);
	
	int size1 = 20;
	int subsize1 = 20;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size1, subsize1);
	int findval = ((rand() % (size1 - 1)) + 1);
	int* ptr = (int*)malloc(sizeof(int) * size1);
	long arr1[100];
	searcher(arr1, ptr, size1, findval, subsize1);
	
	int size2 = 1;
	int subsize2 = 1;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size2, subsize2);
	if(size2 == 1)
	{
		findval = 1;
	}
	else
	{
		findval = ((rand() % (size2 - 1)) + 1);
	}
	ptr = (int*)malloc(sizeof(int) * size2);
	long arr2[100];
	searcher(arr2, ptr, size2, findval, subsize2);
	
	int size3 = 2;
	int subsize3 = 2;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size3, subsize3);
	findval = ((rand() % (size3 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size3);
	long arr3[100];
	searcher(arr3, ptr, size3, findval, subsize3);
	
	int size10 = 4;
	int subsize10 = 4;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size10, subsize10);
	findval = ((rand() % (size10 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size10);
	long arr10[100];
	searcher(arr10, ptr, size10, findval, subsize10);
	
	int size9 = 8;
	int subsize9 = 8;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size9, subsize9);
	findval = ((rand() % (size9 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size9);
	long arr9[100];
	searcher(arr9, ptr, size9, findval, subsize9);
	
	int size8 = 16;
	int subsize8 = 16;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size8, subsize8);
	findval = ((rand() % (size8 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size8);
	long arr8[100];
	searcher(arr8, ptr, size8, findval, subsize8);
	
	int size7 = 32;
	int subsize7 = 32;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size7, subsize7);
	findval = ((rand() % (size7 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size7);
	long arr7[100];
	searcher(arr7, ptr, size7, findval, subsize7);
	
	int size6 = 64;
	int subsize6 = 64;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size6, subsize6);
	findval = ((rand() % (size6 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size6);
	long arr6[100];
	searcher(arr6, ptr, size6, findval, subsize6);
	
	int size4 = 128;
	int subsize4 = 128;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size4, subsize4);
	findval = ((rand() % (size4 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size4);
	long arr4[100];
	searcher(arr4, ptr, size4, findval, subsize4);
	
	int size5 = 250;
	int subsize5 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n\n", size5, subsize5);
	findval = ((rand() % (size5 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size5);
	long arr5[100];
	searcher(arr5, ptr, size5, findval, subsize5);
	
	free(ptr);
	
	long mean1, mean2, mean3, mean4, mean5, mean6, mean7, mean8, mean9, mean10;
	long min1, min2, min3, min4, min5, min6, min7, min8, min9, min10;
	long max1, max2, max3, max4, max5, max6, max7, max8, max9, max10;
	double std1, std2, std3, std4, std5, std6, std7, std8, std9, std10;
	
	calculateStats(min1, max1, mean1, std1, size1, subsize1, arr1);
	calculateStats(min2, max2, mean2, std2, size2, subsize2, arr2);
	calculateStats(min3, max3, mean3, std3, size3, subsize3, arr3);
	calculateStats(min10, max10, mean10, std10, size10, subsize10, arr10);
	calculateStats(min9, max9, mean9, std9, size9, subsize9, arr9);
	calculateStats(min8, max8, mean8, std8, size8, subsize8, arr8);
	calculateStats(min7, max7, mean7, std7, size7, subsize7, arr7);
	calculateStats(min6, max6, mean5, std6, size6, subsize6, arr6);
	calculateStats(min4, max4, mean4, std4, size4, subsize4, arr4);
	calculateStats(min5, max5, mean5, std5, size5, subsize5, arr5);
	
	
	gettimeofday(&time02, 0);
	timeTestA = (time02.tv_sec-time01.tv_sec)*1000000 + time02.tv_usec-time01.tv_usec;
	
	return timeTestA;
}

long testB()
{
	int i;
	printf("Running Test Case B.\n");
	long timeTestA;
	struct timeval time01;
	struct timeval time02;
	gettimeofday(&time01, 0);
	int findval;
	
	int size1 = 2;
	int subsize1 = 1;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size1, subsize1);
	if(size1 == 1)
	{
		findval = 1;
	}
	else
	{
		findval = ((rand() % (size1 - 1)) + 1);
	}
	int* ptr = (int*)malloc(sizeof(int) * size1);
	long arr1[100];
	searcher(arr1, ptr, size1, findval, subsize1);
	
	int size2 = 2;
	int subsize2 = 1;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size2, subsize2);
	if(size2 == 1)
	{
		findval = 1;
	}
	else
	{
		findval = ((rand() % (size2 - 1)) + 1);
	}
	ptr = (int*)malloc(sizeof(int) * size2);
	long arr2[100];
	searcher(arr2, ptr, size2, findval, subsize2);
	
	int size3 = 2;
	int subsize3 = 1;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size3, subsize3);
	findval = ((rand() % (size3 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size3);
	long arr3[100];
	searcher(arr3, ptr, size3, findval, subsize3);
	
	int size10 = 4;
	int subsize10 = 2;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size10, subsize10);
	findval = ((rand() % (size10 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size10);
	long arr10[100];
	searcher(arr10, ptr, size10, findval, subsize10);
	
	int size9 = 8;
	int subsize9 = 4;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size9, subsize9);
	findval = ((rand() % (size9 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size9);
	long arr9[100];
	searcher(arr9, ptr, size9, findval, subsize9);
	
	int size8 = 16;
	int subsize8 = 8;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size8, subsize8);
	findval = ((rand() % (size8 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size8);
	long arr8[100];
	searcher(arr8, ptr, size8, findval, subsize8);
	
	int size7 = 32;
	int subsize7 = 16;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size7, subsize7);
	findval = ((rand() % (size7 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size7);
	long arr7[100];
	searcher(arr7, ptr, size7, findval, subsize7);
	
	int size6 = 64;
	int subsize6 = 32;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size6, subsize6);
	findval = ((rand() % (size6 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size6);
	long arr6[100];
	searcher(arr6, ptr, size6, findval, subsize6);
	
	int size4 = 128;
	int subsize4 = 64;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size4, subsize4);
	findval = ((rand() % (size4 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size4);
	long arr4[100];
	searcher(arr4, ptr, size4, findval, subsize4);
	
	int size5 = 250;
	int subsize5 = 125;
	printf("Searching a list of %d integers with subsize %d 100 times.\n\n", size5, subsize5);
	findval = ((rand() % (size5 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size5);
	long arr5[100];
	searcher(arr5, ptr, size5, findval, subsize5);
	
	free(ptr);
	
	long mean1, mean2, mean3, mean4, mean5, mean6, mean7, mean8, mean9, mean10;
	long min1, min2, min3, min4, min5, min6, min7, min8, min9, min10;
	long max1, max2, max3, max4, max5, max6, max7, max8, max9, max10;
	double std1, std2, std3, std4, std5, std6, std7, std8, std9, std10;
	
	calculateStats(min1, max1, mean1, std1, size1, subsize1, arr1);
	calculateStats(min2, max2, mean2, std2, size2, subsize2, arr2);
	calculateStats(min3, max3, mean3, std3, size3, subsize3, arr3);
	calculateStats(min10, max10, mean10, std10, size10, subsize10, arr10);
	calculateStats(min9, max9, mean9, std9, size9, subsize9, arr9);
	calculateStats(min8, max8, mean8, std8, size8, subsize8, arr8);
	calculateStats(min7, max7, mean7, std7, size7, subsize7, arr7);
	calculateStats(min6, max6, mean5, std6, size6, subsize6, arr6);
	calculateStats(min4, max4, mean4, std4, size4, subsize4, arr4);
	calculateStats(min5, max5, mean5, std5, size5, subsize5, arr5);
	
	
	gettimeofday(&time02, 0);
	timeTestA = (time02.tv_sec-time01.tv_sec)*1000000 + time02.tv_usec-time01.tv_usec;
	
	return timeTestA;
}

long testC()
{
	int i;
	printf("Running Test Case C.\n");
	long timeTestA;
	struct timeval time01;
	struct timeval time02;
	gettimeofday(&time01, 0);
	int size1 = 250;
	int subsize1 = 250;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size1, subsize1);
	int findval = ((rand() % (size1 - 1)) + 1);
	int* ptr = (int*)malloc(sizeof(int) * size1);
	long arr1[100];
	searcher(arr1, ptr, size1, findval, subsize1);
	
	int size2 = 250;
	int subsize2 = 125;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size2, subsize2);
	findval = ((rand() % (size2 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size2);
	long arr2[100];
	searcher(arr2, ptr, size2, findval, subsize2);

	int size3 = 250;
	int subsize3 = 84;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size3, subsize3);
	findval = ((rand() % (size3 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size3);
	long arr3[100];
	searcher(arr3, ptr, size3, findval, subsize3);
	
	int size4 = 250;
	int subsize4 = 63;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size4, subsize4);
	findval = ((rand() % (size4 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size4);
	long arr4[100];
	searcher(arr4, ptr, size4, findval, subsize4);
	
	int size5 = 250;
	int subsize5 = 50;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size5, subsize5);
	findval = ((rand() % (size5 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size5);
	long arr5[100];
	searcher(arr5, ptr, size5, findval, subsize5);
	
	int size6 = 250;
	int subsize6 = 42;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size6, subsize6);
	findval = ((rand() % (size6 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size6);
	long arr6[100];
	searcher(arr6, ptr, size6, findval, subsize6);
	
	int size7 = 250;
	int subsize7 = 36;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size7, subsize7);
	findval = ((rand() % (size7 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size7);
	long arr7[100];
	searcher(arr7, ptr, size7, findval, subsize7);
	
	int size8 = 250;
	int subsize8 = 32;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size8, subsize8);
	findval = ((rand() % (size8 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size8);
	long arr8[100];
	searcher(arr8, ptr, size8, findval, subsize8);
	
	int size9 = 250;
	int subsize9 = 28;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size9, subsize9);
	findval = ((rand() % (size9 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size9);
	long arr9[100];
	searcher(arr9, ptr, size9, findval, subsize9);
	
	int size10 = 250;
	int subsize10 = 25;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size10, subsize10);
	findval = ((rand() % (size10 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size10);
	long arr10[100];
	searcher(arr10, ptr, size10, findval, subsize10);
	
	int size11 = 250;
	int subsize11 = 23;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size11, subsize11);
	findval = ((rand() % (size11 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size11);
	long arr11[100];
	searcher(arr11, ptr, size11, findval, subsize11);
	
	int size12 = 250;
	int subsize12 = 21;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size12, subsize12);
	findval = ((rand() % (size12 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size12);
	long arr12[100];
	searcher(arr12, ptr, size12, findval, subsize12);
	
	int size13 = 250;
	int subsize13 = 20;
	printf("Searching a list of %d integers with subsize %d 100 times.\n", size13, subsize13);
	findval = ((rand() % (size13 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size13);
	long arr13[100];
	searcher(arr13, ptr, size13, findval, subsize13);
	
	int size14 = 250;
	int subsize14 = 18;
	printf("Searching a list of %d integers with subsize %d 100 times.\n\n", size14, subsize14);
	findval = ((rand() % (size14 - 1)) + 1);
	ptr = (int*)malloc(sizeof(int) * size14);
	long arr14[100];
	searcher(arr14, ptr, size14, findval, subsize14);
	
	
	free(ptr);
	
	long mean1, mean2, mean3, mean4, mean5, mean6, mean7, mean8, mean9, mean10, mean11, mean12, mean13, mean14;
	long min1, min2, min3, min4, min5, min6, min7, min8, min9, min10, min11, min12, min13, min14;
	long max1, max2, max3, max4, max5, max6, max7, max8, max9, max10, max11, max12, max13, max14;
	double std1, std2, std3, std4, std5, std6, std7, std8, std9, std10, std11, std12, std13, std14;
	
	calculateStats(min1, max1, mean1, std1, size1, subsize1, arr1);
	calculateStats(min2, max2, mean2, std2, size2, subsize2, arr2);
	calculateStats(min3, max3, mean3, std3, size3, subsize3, arr3);
	calculateStats(min4, max4, mean4, std4, size4, subsize4, arr4);
	calculateStats(min5, max5, mean5, std5, size5, subsize5, arr5);
	calculateStats(min6, max6, mean6, std6, size6, subsize6, arr6);
	calculateStats(min7, max7, mean7, std7, size7, subsize7, arr7);
	calculateStats(min8, max8, mean8, std8, size8, subsize8, arr8);
	calculateStats(min9, max9, mean9, std9, size9, subsize9, arr9);
	calculateStats(min10, max10, mean10, std10, size10, subsize10, arr10);
	calculateStats(min11, max11, mean11, std11, size11, subsize11, arr11);
	calculateStats(min12, max12, mean12, std12, size12, subsize12, arr12);
	calculateStats(min13, max13, mean13, std13, size13, subsize13, arr13);
	calculateStats(min14, max14, mean14, std14, size14, subsize14, arr14);
	
	
	gettimeofday(&time02, 0);
	timeTestA = (time02.tv_sec-time01.tv_sec)*1000000 + time02.tv_usec-time01.tv_usec;
	
	return timeTestA;
}
int main(int argc, char** argv)
{
	long timepassed = testA();
	printf("\n");
	printf("Time elapsed for Test A: %ld microseconds\n", timepassed);
	printf("\n");
	
	long timepassed2 = testB();
	printf("\n");
	printf("Time elapsed for Test B: %ld microseconds\n", timepassed2);
	printf("\n");
	
	// testB1() should be run only with processing. uncomment if needed.
	/*long timepassed3 = testB1();
	printf("\n");
	printf("Time elapsed for Test A: %ld microseconds\n", timepassed3);
	printf("\n");*/
	
	long timepassed1 = testC();
	printf("\n");
	printf("Time elapsed for Test C: %ld microseconds\n", timepassed1);
	printf("\n");
}
