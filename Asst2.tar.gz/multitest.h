#ifndef _MULTITEST_H
#define _MULTITEST_H
#define dummy(x, y, z, w) search(x, y, z, w)
//#include <stdlib.h>
#include "multitest.h"
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <math.h>
#include <signal.h>
#include <stdlib.h>

int search(int* ptr, int size, int findval, int subsize);
void* iterateSearch(void* data);
struct arguments{
    int* array;
    int numThreads1;
    int subsize1;
    int x;
    int remaining;
    int findval1;
};
struct returner{
  int y;
  int z;

};
#endif
