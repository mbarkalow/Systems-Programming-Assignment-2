#include "multitest.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>


void* iterateSearch(void* data)// This is the function that threads are sent to to search their segment of the array.
{
	//printf("HELLO IM HERE");
  struct returner* threader; // declares a returner struct so that the thread can return values
  struct arguments* threader2;// we need to declare a struct arguments pointer so that we can evaluate parameters sent in as "data" by the pthread_create
	
	
	
  threader2 = (struct arguments*)data;
  
  threader = (struct returner*)malloc(sizeof(struct returner));
 
  int startPoint = threader2->x * threader2->subsize1;// To find what segment of the array a thread is supposed to search I calculate it by multiplying the index by the subsize to get the starting point.
  int endPoint = ((threader2->x)+1) * threader2->subsize1;// to find the endpoint the thread is supposed to search we multiply it by the index+1 by the subsize.
  if(((threader2->x)+1) == threader2->numThreads1){// if the current thread is the last thread then we examine the remaining number of elements to calculate the endpoint
    if(threader2->remaining != 0) // if the remaining is 0 then we do nothing
      endPoint = startPoint + threader2->remaining;// if remaining is not 0 then the remaining is added to the endpoint.

  }
  
  
  int z = 0;
  int tester = 0;
  for(z = startPoint; z < endPoint; z++){
    if(threader2->array[z] == threader2->findval1){//Here we iterate through the array to determine if the findval is in the corresponding thread's segement.
      tester = 1;
      threader->y = z;
      //printf("thread that found findval is: %d\n", threader2->x);
      threader->z = pthread_self();
    }

  }
  if(tester == 0){
    threader->y = (threader2->numThreads1 * threader2->subsize1) + 1;
    threader->z = pthread_self();
  }
  //free(threader2);
  pthread_exit(threader);
}


int search(int* ptr, int size, int findval, int subsize)
{
  //printf("IM HERE");
  int remaining = 0;
  int numThreads = size/subsize; // this obviously gets the minimum required threads to search the given array
 
  if((size % subsize) != 0)// if the size mod subsize is not 0, then that means that the last thread must process a numnber of elements less than the subsize so we have to figure out how many they have to process.
    {
      int x = numThreads * subsize; // this will get how many elements will be processed evenly according to the subsize.
      remaining = size - x; // if we subtract the total size by x, that will give us the remaining elements.
      numThreads++;
    }
  pthread_t thread[numThreads];// since we know how many threads are required, I declare a pthread_t array with the corresponding number of threads
  struct arguments* starter;// this struct of type arguments will be used to pass parameters such as the array to be searched, findval, etc.. when pthread_create is called.
  starter = (struct arguments*)malloc((numThreads) * sizeof(struct arguments));
  
  int h = 0;
  
  for(h = 0;h < numThreads; h++){// since we know how many threads will be created, we also know how many struct argument pointers we need, so all the parameters for each call is initialized here.
  	starter[h].array = ptr;
  	starter[h].numThreads1 = numThreads;
  	starter[h].subsize1 = subsize;
  	starter[h].findval1 = findval;
  	starter[h].remaining = remaining;
  	starter[h].x = h;// I pass the index of each thread so each thread knows what values to search for in the array
  
  
  }
  
  int i = 0;
  for(i = 0; i < numThreads; i++){
  	
  
  	
    pthread_create(&thread[i], NULL, iterateSearch, &starter[i]);//Here we run a for loop to start the required number of threads to search the array and send these threads to "iterateSearch" with the parameters of its respective starter index
  }
  int a = 0;
  int finalIndex = 0;
  int threadId = 0;
  struct returner* abc;// I declare a struct of this type to be able to retrieve values sent back over the join statement.
  for(a = 0; a < numThreads; a++){
    pthread_join(thread[a], (void**)&abc);// I run a for loop to join all the threads and evaluate their return values.
    if(abc->y != ((numThreads * subsize) + 1)){// if the index(integer) returned is out of scope of the possible indexes that could be returned, then I know that that thread did not find the value in its segment
      finalIndex = abc->y;// In the case that the index returned is in the scope of possible indexes, then I would free all dynamic allocations I made with the structs and return 1 to signal that the value was found
      threadId = abc->z;
      free(starter);
  	free(abc); 	
      return 1;
      
      
	
    }
  }
  free(starter);
  free(abc); 	 
  //printf("the value was not found");
  return -1;// -1 is returned if the value is not found in any of the threads, but this should never happen
  

  
  
}
  




